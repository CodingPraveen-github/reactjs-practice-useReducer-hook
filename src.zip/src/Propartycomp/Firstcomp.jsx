import React from 'react'

const Firstcomp = () => {
  return (
    <h2>iam true value</h2>
  )
}

export default Firstcomp