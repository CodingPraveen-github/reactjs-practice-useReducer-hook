
import React, { useState } from 'react'

  import { ToastContainer, toast } from 'react-toastify';




const FormExample = () => {

  const[userName,setUserName] = useState("")

  const[newUser,setNewUser] = useState("")

  const notify = () => toast("Wow so easy!");

  const getUserName =(event)=>{
    setUserName(event.target.value)
  }

  const userDetails = (e)=>{
    e.preventDetails()
    setNewUser(userName)
    notify()

  }
  return (
    <section className='formsection'>
      <h2>Hi, {newUser}</h2>
      <ToastContainer />
      
      <div className='divinput'>
      <form onSubmit={userDetails}>
        <input type="text" placeholder='Enter your name' onChange={getUserName}/>
        <br />
        <button className='btn' type='submit'>Submit</button>
        </form>
      </div>
      
      </section>
  )
}

export default FormExample