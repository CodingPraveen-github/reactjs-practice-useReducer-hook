import React from 'react'

const userDetails = "https://jsonplaceholder.typicode.com/posts"
console.log(userDetails)

import { useState,useEffect } from 'react'
const UserPage = () => {
    const [user,setUser] = useState([])

    const userHanler = async() =>{
        const responce = await fetch(userDetails);
        const userData =await  responce.json();
        setUser(userData);

     
        
    };
    useEffect(()=>{
        console.log(userHanler())
    },[]);
      return <div>
        {user.map(()=>{

        })}
      </div>     
}

export default UserPage;