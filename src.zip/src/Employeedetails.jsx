import React,{useState} from 'react'


const Employeedetails = () => {

    const [name,setName] = useState("")
    const [role,setRole] = useState("")
    const [email,setEmail] = useState("")
    const [dept,setDept] = useState("")

    const empDetails = {name,role,email,dept}
    const empHandler = (e) =>{
        e.preventDefult()
        console.log(empDetails)
        const responce = fetch ("http://localhost5000",{
        method:"POST",
        headers:{
            "Content-Type":"Application-json"
        },
        body:JSON.stringify(empDetails)
    })}
  return (
    <div className="Empform" >
        <div className="section">
            <form onSubmit={empHandler}>
            <label >Employee Name</label>
            <input type="text" name='name' onClick={(e)=>setName(e.target.value)} />
            <label >Employee Role</label>
            <input type="text" name='role' onClick={(e)=>setRole(e.target.value)}/>
            <label >Employee email</label>
            <input type="email" name='email'onClick={(e)=>setEmail(e.target.value)} />
            <label >Employee Dept</label>
            <input type="text" name='dept' onClick={(e)=>setDept(e.target.value)}/>
            <button type="submit">Submit</button>
            </form>          
        </div>   
    </div>
  )
}

export default Employeedetails


